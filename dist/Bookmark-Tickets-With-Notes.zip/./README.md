## Bookmark Tickets

Bookmark Tickets is an app which allows agents to bookmark a couple of tickets in Freshservice with personal notes and revisit them whenever they want to. 
It also provides an option to agents for giving voice notes.

Bookmark Tickets stores the ticket bookmarked with notes. It will help agent to remember and revisit tickets important to them. Notes Associated with tickets will help the agent to remember customer response or detailed requirement.
Now, easily handle multiple important tickets using Bookmark Tickets in Freshservice.
